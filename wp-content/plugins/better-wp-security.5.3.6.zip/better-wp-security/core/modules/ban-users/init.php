<?php

class ITSEC_Ban_Users_Module_Init extends ITSEC_Module_Init {
	protected $_id   = 'ban-users';
	protected $_name = 'Ban Users';
	protected $_desc = 'Ban users.';
}
new ITSEC_Ban_Users_Module_Init();
