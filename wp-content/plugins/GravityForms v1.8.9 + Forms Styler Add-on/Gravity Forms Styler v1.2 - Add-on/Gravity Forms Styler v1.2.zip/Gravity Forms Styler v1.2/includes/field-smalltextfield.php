						<input name="<?php echo $name; ?>" type="text" ref="<?php echo $groupid; ?>" id="<?php echo $id; ?>" value="<?php echo htmlentities( $value ); ?>"/>
